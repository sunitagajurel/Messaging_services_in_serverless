from Inspector import Inspector
from kombu import Connection

conn = None
batch_size = None

def connect_kafka(host):
    global conn
    global batch_size
    conn = Connection(host,
            transport_options={
            'batch_size':batch_size,
            'security_protocol': 'SASL_SSL',
            'sasl_mechanism':'SCRAM-SHA-512',
})

def send_to_kafka(msg,host):
    if not conn: 
        connect_kafka(host)

    try:
        producer = conn.Producer(serializer='json')
        producer.publish(msg,"test")
    except Exception as e:
        raise(e)

  
def handler(event,context):
    inspector = Inspector()
    inspector.inspectContainer()
    msg = event['msg']
    batch_size = event['batch_size'] if "batch_size" in event else 1
    sleep = event['sleep'] if "sleep" in event else 0
     # for warm containers
    if not sleep:
        send_to_kafka(msg,event['host'])
     # setting up sleep value to  warm multiple containers 
    else:
        time.sleep(sleep)
    return inspector.finish()