from Inspector import Inspector
from confluent_kafka import Producer
import time

conn = None
batch_size = None
def connect_kafka(host):
    global conn
    global batch_size
    conf = {
            'bootstrap.servers':host,
            'batch.size': batch_size,  # Adjust the batch size as needed
            # 'queue.buffering.max.messages': 10000000,  # Increase this value
            'security.protocol': 'SASL_SSL',
            'sasl.username': "alice",
            'sasl.password': "alice-secret",
            'sasl.mechanism': 'SCRAM-SHA-512'  
        } 
        conn = Producer(**conf)

def send_to_kafka(msg,host):
    if not conn: 
        connect_kafka(host)
    try:
        conn.produce("test",msg)
        conn.flush()
    except Exception as e:
        raise(e)

    
def handler(event,context):
    global batch_size
    inspector = Inspector()
    inspector.inspectContainer()
    msg = event['msg']
    batch_size = event['batch_size'] if "batch_size" in event else 1
    sleep = event['sleep'] if "sleep" in event else 0
     # for warm containers
    if not sleep:
        send_to_kafka(msg,event['host'])
     # setting up sleep value to  warm multiple containers 
    else:
        time.sleep(sleep)
    return inspector.finish()